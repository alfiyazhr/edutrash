package com.example.edutrash.model

class User {
}