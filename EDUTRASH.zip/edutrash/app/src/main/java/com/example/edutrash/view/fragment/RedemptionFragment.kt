package com.example.edutrash.view.fragment

import androidx.fragment.app.Fragment
import com.example.edutrash.R

class RedemptionFragment : Fragment(R.layout.fragment_redemption) {
}
