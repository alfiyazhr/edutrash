package com.example.edutrash.helper

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import com.example.edutrash.R
import org.tensorflow.lite.DataType
import org.tensorflow.lite.support.image.TensorImage
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer
import com.example.edutrash.ml.GarbageClassificationModel

class ImageClassifierHelper(
    private val threshold: Float = 0.1f,
    private val maxResults: Int = 1,
    private val context: Context,
    private val classifierListener: ClassifierListener?
) {
    private val TAG = "ImageClassifierHelper"

    interface ClassifierListener {
        fun onError(error: String)
        fun onResults(results: List<String>, inferenceTime: Long)
    }

    fun classifyImage(bitmap: Bitmap) {
        try {
            val model = GarbageClassificationModel.newInstance(context)

            // Resize or verify bitmap dimensions (ensure 224x224)
            val tensorImage = TensorImage(DataType.FLOAT32)
            tensorImage.load(bitmap)

            // Create input buffer (size 1x224x224x3)
            val inputFeature0 = TensorBuffer.createFixedSize(
                intArrayOf(1, 224, 224, 3),
                DataType.FLOAT32
            )
            inputFeature0.loadBuffer(tensorImage.buffer)

            // Run inference
            val startTime = System.currentTimeMillis()
            val outputs = model.process(inputFeature0)
            val outputFeature0 = outputs.outputFeature0AsTensorBuffer
            val inferenceTime = System.currentTimeMillis() - startTime

            // Get results and apply threshold
            val labels = context.resources.getStringArray(R.array.garbage_labels)
            val scores = outputFeature0.floatArray
            val results = labels.indices
                .filter { scores[it] >= threshold }
                .sortedByDescending { scores[it] }
                .take(maxResults)
                .map { labels[it] to scores[it] }

            model.close()

            // Return results through listener
            classifierListener?.onResults(
                results.map { "${it.first}: ${"%.2f".format(it.second)}" },
                inferenceTime
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error during model inference: ${e.message}")
            classifierListener?.onError(context.getString(R.string.image_classifier_failed))
        }
    }

}
